#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
class Bus                                    
{
    public:
    char Busid[20];
    char BusNo[20];
    char DriverName[20];
    char Departure[20];
    char Arrival[20];
    char From[20];
    char To[20];
    char Date[20];
    char Day[20];
    char Seats[20];
    Bus ( )
    {
    strcpy(Busid,"");
    strcpy(BusNo," ");
    strcpy(DriverName," ");
    strcpy(Departure," ");
    strcpy(Arrival," ");
    strcpy(From," ");
    strcpy(To," ");
    strcpy(Date," ");
    strcpy(Day," ");
    strcpy(Seats," ");
    }
    void Tabular()
    {   
        cout<<"\t\t\t*****BUS DETAILS*****"<<"\n\n";
        cout<<"Bus ID:"<<Busid<<"\n";
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        cout<<"Bus Number"<<"\tDriver Name"<<"\tDeparture"<<"\tArrival"<<"\n";
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        cout<<BusNo<<"\t\t"<<DriverName<<"\t"<<Departure<<"\t\t"<<Arrival<<"\n";
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        cout<<"Date"<<"\t\tFrom"<<"\t\t To"<<"\t\t\tTotal Number of Seats"<<"\n";
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        cout<<Date<<"\t"<<From<<"\t\t"<<To<<"\t\t\t"<<Seats<<"\n";
        cout<<"----------------------------------------------------------------------------------"<<"\n";
    }
};
class book : public Bus
{
    Bus B1;

    public:
    int sno;
    char Sbusno[20];
    char From[20];
    char To[20];
    char Date[20];

    char name[20];
    int age;
    char email[40];
    char address[40];
    char password[20];
    char Password[20];
    char Gender[20];
    book()
    {
        sno=0;
        strcpy(Sbusno,"");
        strcpy(From,"");
        strcpy(To,"");
        strcpy(Date,"");

         strcpy(name,"");
    age=0;
    strcpy(email,"");
    strcpy(address," ");
    strcpy(password,"");
    strcpy(Password,"");
    strcpy(Gender,"");
    }

     void Display1()
   {   
       cout<<"\t\t\t*****PERSONAL DETAILS*****"<<"\n\n";
       cout<<"Name:"<<name<<"\n";
       cout<<"Age:"<<age<<"\n";
       cout<<"Gender:"<<Gender<<"\n";
       cout<<"E-Mail:"<<email<<"\n";
       cout<<"Address:"<<address<<"\n";
       cout<<"Password:"<<Password<<"\n";
       cout<<"THANK YOU!"<< name <<" FOR ADDING YOUR PERSONAL DETAILS"<<"\n";
   }
   void displaybook()
   {
       cout<<"\t\t\t*****BOOKING DETAILS*****"<<"\n";
       cout<<"++++++++++++++++++++++++++++++++++++++++++++++"<<"\n";
       cout<<"**BUS TICKET**"<<"\n";
        cout<<"++++++++++++++++++++++++++++++++++++++++++++++"<<"\n";
       cout<<"Bus Id:"<<B1.Busid<<"\n";
       cout<<"----------------------------------------------------------------------------------"<<"\n";
       cout<<"Date:"<<B1.Date<<"\n";
       cout<<"----------------------------------------------------------------------------------"<<"\n";
       cout<<"Departure From:"<<B1.From<<" at "<<B1.Departure<<"\n";
       cout<<"----------------------------------------------------------------------------------"<<"\n";
       cout<<"Arrive To:"<<B1.To<<" at "<<B1.Arrival<<"\n";
       cout<<"----------------------------------------------------------------------------------"<<"\n";
       cout<<"Seats Booked:"<<sno<<"\n\n\n";
        cout<<"++++++++++++++++++++++++++++++++++++++++++++++"<<"\n";
       cout<<"**CUSTOMER DETAILS**"<<"\n";
       cout<<"Name:"<<name<<"\n";
        cout<<"Age:"<<age<<"\n";
       cout<<"Gender:"<<Gender<<"\n";
       cout<<"E-Mail:"<<email<<"\n";
       cout<<"Address:"<<address<<"\n";

   }
};
 int search() 
{
    Bus B1;
    book B2;
    ofstream fob("book.dat",ios::app|ios::binary);
    ifstream fin("Bus1.dat", ios::binary);
    if(!fin)
    {
    cout<<"There is No Bus For this Rout";
    }
    int s=0;    
    string find;
    string found;
    string Time;
    cout<<"Enter a Journey you Start From:";
    cin>>find;
    cout<<"Enter a Journey you End To:";
    cin>>found;
    cout<<"Date Of Journey (Date/Month/Year):";
    cin>>Time;
    while(fin.read((char*)(&B1), sizeof(B1)))
    {
        if(find==B1.From && found==B1.To && Time==B1.Date)
        {
        s=1;
        cout<<"Bus is Found"<<"\n";
        B1.Tabular();
        cout<<"\t\t\t***CONTINUE THE AMAZING JOURNEY***"<<"\n";
        cout<<"--PLEASE ENTER YOUR PERSONAL DETAILS FOR BOOKING TICKETS---"<<"\n";

        cout<<"Enter Your Name:";
        cin>>B2.name;
        cout<<"Enter Your Age:";
        cin>>B2.age;
        cout<<"Enter Your Gender(Male/Female):";
        cin>>B2.Gender;
        cout<<"Enter Your E-Mail:";
        cin>>B2.email;
        cout<<"Enter Your Address:";
        cin>>B2.address;
        cout<<"Enter Your Password :";
        cin>>B2.Password;
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        cout<<"Enter Number of Seats:";
        cin>>B2.sno;
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        cout<<"Thank You ! For Choicing This Bus"<<"\n";
        cout<<"----------------------------------------------------------------------------------"<<"\n";
        }
    }
    
     if(B1.From!=find || found!=B1.To || Time!=B1.Date)
   {
       cout<<"Bus is not found"<<"\n";
    }
    return s;
    fob.close();
    fin.close();
}
void Book()
{
    ofstream fob("book.dat",ios::app|ios::binary);
    while(true)
    {
    int s=search();
    if(s==1)
        break;
    else
        cout<<"";
    }
    fob.close();
}
void bookread()
{
   book B2;
   Bus B1;
   ifstream fin("Bus1.dat",ios::binary);
   ifstream fib("book.dat",ios::binary);
   for(;fib.read((char*)(&B2), sizeof(B2));)
   {
    B2.displaybook();
   }
   fib.close();
   cout<<"----------------------------------------------------------------------------------"<<"\n";
   cout<<"SUCCESSFUL YOUR SEAT IS ALLOTED"<<"\n";
   cout<<"----------------------------------------------------------------------------------"<<"\n";
   cout<<"----------------------------------------------------------------------------------"<<"\n";
   cout<<"Thank You ! For Choicing This Bus"<<"\n";
   cout<<"----------------------------------------------------------------------------------"<<"\n"; 
}
int main()
{
    search();
    Book();
    // bookread();
}