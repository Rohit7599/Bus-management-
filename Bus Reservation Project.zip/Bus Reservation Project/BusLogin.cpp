#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;
int main()
{
    string Bus;
    string password;
    string Name;
    string ch;
    cout<<"*****Security Are Required*****\n\n\t\t\t";
    cout<<"Name:";
    cin>>Name;
    cout<<"Password:\n\n";
    cin>>password;
    
    if(Name=="Rohit Singla" && password=="RohitBus")
    {
        cout<<"Loading........\n\n\t";
    }
    else
    {
        cout<<"Your Name and Password is Incorrect....\n\n\t";
        
    }
}